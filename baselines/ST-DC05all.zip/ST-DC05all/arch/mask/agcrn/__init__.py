from .agcn import AVWGCN

__all__ = ['AVWGCN']
