from .model import GraphWaveNet

__all__ = ['GraphWaveNet']
