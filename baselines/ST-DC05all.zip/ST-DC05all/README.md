STDMAE requires the following dependencies:

- positional_encodings==6.0.1
- timm==0.6.7

You can download the checkpoints from [`the original repo`](https://github.com/Jimmy-7664/STD-MAE/tree/main/mask_save) and place it to `baselines/STDMAE/mask_save`.
